<?php session_start(); ?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cybertron Port Authority &middot; Home</title>
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body style="height:auto; min-height:100vh; align-items:stretch; padding:0;">
    <?php include "header.php"; ?>
    <main style="width:100%; max-width:820px; min-height:100vh; box-sizing:border-box; margin:0 auto; padding:0 1rem; text-align:center; display:flex; flex-direction:column; justify-content:center; align-items:center;">
        <?php if (isset($_SESSION['name'])) {
            $rol = $_SESSION['role'] === 'admin' ? 'Admin (haven/douane)' : 'Bezoeker (rederij)';
            echo '<h1 class="welcome-name">Welkom, ' . htmlspecialchars($_SESSION['name']) . '!</h1>';
            echo '<h2 class="user-role">Je bent een ' . $rol . '</h2>';

            // [VLAG 2] Alleen zichtbaar voor admin, bereikbaar via de SQLi-login.
            if ($_SESSION['role'] === 'admin') {
                echo '<p style="text-align:center; font-family:monospace; color:#5c4fbb;">Systeemsleutel: THM{VERVANG_DIT_VLAG_2}</p>';
            }
        } else {
            echo '<h1 class="welcome-name">Je bent niet ingelogd!</h1>';
            echo '<p class="user-role">Om verder te gaan, <a href="login.php" class="login-link">log hier in</a>.</p>';
        } ?>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
