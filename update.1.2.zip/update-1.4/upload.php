<?php
session_start();
include 'config.php';
// Inloggen vereist (douanedocumenten horen bij ingelogde gebruikers).
if (!isset($_SESSION['name'])) { header("Location: login.php"); exit; }

$msg = '';
if (isset($_POST['submit']) && isset($_FILES['doc'])) {
    // [KWETSBAARHEID #6 - Upload zonder controle / A04 Insecure Design]
    // Geen controle op bestandstype of extensie; de map is via het web
    // benaderbaar. Bewuste neven-zwakte, niet op het winnende pad.
    $dir = __DIR__ . '/uploads/';
    if (!is_dir($dir)) { mkdir($dir, 0755, true); }
    $name = basename($_FILES['doc']['name']);
    if (move_uploaded_file($_FILES['doc']['tmp_name'], $dir . $name)) {
        $msg = 'Document opgeslagen: ' . htmlspecialchars($name);
    } else {
        $msg = 'Upload mislukt.';
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cybertron &middot; Documenten</title>
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body style="height:auto; min-height:100vh; align-items:flex-start; padding-top:9rem;">
    <?php include "header.php"; ?>
    <main style="width:100%; max-width:620px; margin:0 auto; padding:0 1rem;">
        <div class="container1" style="width:100%; margin-top:0;">
            <h1 class="welcome-name" style="font-size:1.8rem;">Douanedocument uploaden</h1>
            <?php if ($msg) { echo '<p style="text-align:center;">'.$msg.'</p>'; } ?>
            <form action="upload.php" method="POST" enctype="multipart/form-data">
                <input type="file" name="doc" required>
                <button name="submit" class="confirm-btn">Uploaden</button>
            </form>
            <p style="margin-top:1.5rem;"><a href="index.php">&larr; Terug naar dashboard</a></p>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
