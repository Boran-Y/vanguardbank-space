<header>
    <!-- ========= NAVBAR BEGIN =======-->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand text-white" href="<?php echo isset($_SESSION['name']) ? 'index.php' : 'index.php#home'; ?>">
                <img src="./fotos/logo-inverted.png" alt="Cybertron Port Authority">
                <em class="navbar-logo-text"></em>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <label class="burger" for="burger">
                    <input id="burger" type="checkbox">
                    <span></span><span></span><span></span>
                </label>
            </button>

            <div class="collapse navbar-collapse" id="navbarResponsive">
                <!-- Midden: navigatielinks -->
                <ul class="navbar-nav mx-auto py-2 py-lg-0 align-items-lg-center">
                    <?php if (isset($_SESSION['name'])) { ?>
                        <li class="nav-item"><a class="nav-link" href="index.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="manifest.php">Manifesten</a></li>
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                            <li class="nav-item"><a class="nav-link" href="upload.php">Documenten</a></li>
                            <li class="nav-item"><a class="nav-link" href="beheer.php">Beheer</a></li>
                        <?php } ?>
                    <?php } else { ?>
                    <!-- <li class="nav-item"><a class="nav-link" href="aanmelden.php">Lading aanmelden</a></li> -->
                    <?php } ?>
                </ul>

                <!-- Rechts: Login / Uitloggen -->
                <ul class="navbar-nav py-2 py-lg-0 align-items-lg-center">
                    <?php if (isset($_SESSION['name'])) { ?>
                        <li class="nav-item">
                            <div class="main-button">
                                <a href="./logout.php">Uitloggen <i class="fa-solid fa-arrow-right-from-bracket loguit-knop"></i></a>
                            </div>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item">
                            <div class="main-button">
                                <a href="./login.php">Login <i class="fa-solid fa-right-to-bracket login-knop"></i></a>
                            </div>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>
    <!-- ========= NAVBAR EINDE =======-->
</header>
<script src="./js/navbar-scroll.js" defer></script>
