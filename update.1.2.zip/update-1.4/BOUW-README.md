# Cybertron Port Authority - in jullie eigen website

> **ALLEEN VOOR HET LAB.** Deze code is opzettelijk kwetsbaar. Alleen op de
> geisoleerde VM / prive TryHackMe-room. Niet op het internet.

Dit is jullie eigen site (design, index en navbar ongewijzigd), met de
kwetsbaarheden erin en de database aangepast. Twee soorten inloggers:
**admin** (haven/douane) en **bezoeker** (rederijen). Nieuwe registraties
worden altijd bezoeker. Alleen admin ziet Beheer en Documenten.

## Wat is er gewijzigd of toegevoegd
| Bestand | Wat |
|---|---|
| `db/cybertron_update.sql` | Importeren: vervangt admin/bezoeker (nepdata) en voegt `manifests` toe |
| `config.php` | Zelfde opzet; alleen een nette comment erbij |
| `login-code.php` | [#2] SQL-injectie in het e-mailveld |
| `manifest.php` | **nieuw** - [#3] IDOR op de manifesten |
| `beheer.php` | **nieuw** - gebruikersexport, alleen voor admin |
| `upload.php` | **nieuw** - [#6] upload zonder controle |
| `index.php` | Dashboard; [VLAG 2] zichtbaar voor admin |
| `header.php` | Opvul-items vervangen door echte: Dashboard, Manifesten, Documenten, Beheer |
| `register.php` | Nieuw account = bezoeker |
| `aanmelden.php` | Ongewijzigd - publieke hint naar FTP (vlag 1) |

De oude `js/script.js` en `js/dashboard.js` (afsprakenproject) zijn eruit;
die gaven een JavaScript-fout en hoorden niet bij dit project. `navbar-scroll.js`
is behouden.

## Kwetsbaarheden en waar ze zitten
| # | Kwetsbaarheid | Waar | Op winnend pad |
|---|---|---|---|
| 1 | Anonieme FTP | server (vsftpd) | ja - vlag 1 |
| 2 | SQL-injectie in login | `login-code.php` | ja - vlag 2 |
| 3 | IDOR op manifesten | `manifest.php` | ja - vlag 2 |
| 4 | Ongezouten MD5-hash | `db/...sql`, `beheer.php` | ja - vlag 3 |
| 5 | Hergebruik wachtwoord SSH | server + db | ja - vlag 3 |
| 6 | Upload zonder controle | `upload.php` | nee |
| 7 | SMB-share (dwaalspoor) | server (Samba) | nee |
| 8 | Verouderde versies | Ubuntu 16.04 stack | nee |

## Winnend pad (ter controle)
1. **Vlag 1** - anonieme FTP, map `/manifests`, bestand `_archief_oud.txt`.
2. **Vlag 2** - login omzeilen met SQL-injectie in het e-mailveld, bijv.
   `' OR '1'='1' --`. Je logt in als admin (beheer_ext) en ziet vlag 2 op het
   dashboard. Via `manifest.php?id=1043` (IDOR) vind je het verdachte manifest
   met de hint naar Beheer; in `beheer.php` staat de gebruikersexport.
3. **Vlag 3** - de MD5-hash van beheer_ext is `starlight` (rockyou). Zelfde
   wachtwoord als voor SSH; inloggen en vlag 3 ophalen.

## Accounts (MD5, geen salt)
| Type | Gebruiker | E-mail | Wachtwoord |
|---|---|---|---|
| admin | beheer_ext | beheer_ext@cybertron.port | `starlight` (**crackbaar**, = SSH) |
| admin | agent.reyes | reyes@cybertron.port | `R3yes!harbor#71` |
| bezoeker | cybertron.freight | freight@cybertron-freight.co | `Fr8ght!Cyb#2017` |

## Opzetten (XAMPP of de VM)
1. Zet alle `.php`, `css/`, `js/`, `fotos/` in de webmap (XAMPP: `htdocs/`, de VM: `/var/www/html/`).
2. Importeer `db/cybertron_update.sql` in de database `project-vanguard-space`.
3. Flags invullen: vlag 1 in `ftp/manifests/_archief_oud.txt`, vlag 2 in `index.php`, vlag 3 als bestand op de VM.
4. FTP, SSH en SMB instellen: zie `SERVER-SETUP.md`.
5. Verwijder de map `uploads/` niet handmatig; die wordt vanzelf gemaakt.
