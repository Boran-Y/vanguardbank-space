<?php
session_start();
include 'config.php';
// Alleen admin mag bij Beheer. Bezoekers worden weggestuurd.
if (!isset($_SESSION['name']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cybertron &middot; Beheer</title>
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body style="height:auto; min-height:100vh; align-items:flex-start; padding-top:9rem; padding-bottom:3rem;">
    <?php include "header.php"; ?>
    <main style="width:100%; max-width:820px; margin:0 auto; padding:0 1rem;">
        <div class="container1" style="width:100%; margin-top:0;">
            <h1 class="welcome-name" style="font-size:1.8rem;">Gebruikersexport</h1>
            <p style="text-align:center;">Export van alle accounts. [#4] de wachtwoorden staan als ongezouten MD5.</p>
            <table class="dataTable" style="width:100%; border-collapse:collapse;">
                <thead><tr><th style="padding:6px 10px;">Gebruiker</th><th style="padding:6px 10px;">E-mail</th><th style="padding:6px 10px;">Wachtwoord (hash)</th><th style="padding:6px 10px;">Type</th></tr></thead>
                <tbody>
                <?php
                $res = mysqli_query($conn, "SELECT name,email,password,'admin' AS soort FROM admin UNION SELECT name,email,password,'bezoeker' FROM bezoeker");
                while ($u = mysqli_fetch_assoc($res)) {
                    echo '<tr><td style="padding:6px 10px;">'.htmlspecialchars($u['name']).'</td>'
                       . '<td style="padding:6px 10px;">'.htmlspecialchars($u['email']).'</td>'
                       . '<td style="padding:6px 10px;"><code>'.$u['password'].'</code></td>'
                       . '<td style="padding:6px 10px;">'.$u['soort'].'</td></tr>';
                }
                ?>
                </tbody>
            </table>
            <p style="margin-top:1.5rem;"><a href="index.php">&larr; Terug naar dashboard</a></p>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
