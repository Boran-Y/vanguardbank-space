<?php
include 'config.php';
session_start();

if (isset($_SESSION['email'])) { header("Location: index.php"); exit; }

$username = '';
$email = '';
if (isset($_POST['submit'])) {
    // Invoer netjes afgeschermd: registreren is GEEN kwetsbaarheid in dit ontwerp.
    $username  = mysqli_real_escape_string($conn, $_POST['username']);
    $email     = mysqli_real_escape_string($conn, $_POST['email']);
    $password  = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if ($password === $cpassword) {
        $check = mysqli_query($conn, "SELECT id FROM bezoeker WHERE email = '$email'");
        if (mysqli_num_rows($check) > 0) {
            echo "<script>alert('E-mail bestaat al.');</script>";
        } else {
            // Nieuw account krijgt altijd het bezoeker-privilege.
            $hashed = md5($password);
            $ins = mysqli_query($conn, "INSERT INTO bezoeker (name, email, password) VALUES ('$username', '$email', '$hashed')");
            if ($ins) {
                echo "<script>alert('Registratie compleet. Klik op OK om in te loggen.'); window.location.href='login.php';</script>";
                exit;
            } else {
                echo "<script>alert('Er is iets misgegaan.');</script>";
            }
        }
    } else {
        echo "<script>alert('Wachtwoorden komen niet overeen.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cybertron Port Authority &middot; Registreren</title>
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" crossorigin="anonymous" />
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/LR.css">
</head>
<body>
    <?php include "header.php"; ?>
    <div class="container2">
        <form action="" method="POST" class="login-email2">
            <img class="logo-styling" src="./fotos/logo.png">
            <div class="input-group2">
                <input id="inputplace" type="text" placeholder="Gebruikersnaam" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
            </div>
            <div class="input-group2">
                <input id="inputplace" type="email" placeholder="E-mail" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div class="input-group2">
                <input id="inputplace" type="password" placeholder="Wachtwoord" name="password" required>
            </div>
            <div class="input-group2">
                <input id="inputplace" type="password" placeholder="Wachtwoord bevestigen" name="cpassword" required>
            </div>
            <div class="input-group2">
                <button style="color:#fff;" name="submit" class="btn2">Registreer</button>
            </div>
            <p class="login-register-text">Heb je al een account? <a href="login.php">Log hier</a> in.</p>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
