<?php
session_start();
include 'config.php';
// Inloggen vereist voor deze pagina.
if (!isset($_SESSION['name'])) { header("Location: login.php"); exit; }

$id = isset($_GET['id']) ? $_GET['id'] : null;
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cybertron &middot; Manifesten</title>
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body style="height:auto; min-height:100vh; align-items:flex-start; padding-top:9rem; padding-bottom:3rem;">
    <?php include "header.php"; ?>
    <main style="width:100%; max-width:760px; margin:0 auto; padding:0 1rem;">
        <div class="container1" style="width:100%; margin-top:0;">
        <?php
        if ($id !== null) {
            // [KWETSBAARHEID #3 - IDOR / A01 Broken Access Control]
            // Elk manifest is opvraagbaar op id, zonder controle of deze
            // gebruiker het mag zien. Zo vindt de aanvaller het verdachte
            // Cybertron Freight-manifest en de hint naar Beheer.
            $id  = (int)$id;
            $res = mysqli_query($conn, "SELECT * FROM manifests WHERE id = $id");
            $m   = $res ? mysqli_fetch_assoc($res) : null;
            if ($m) {
                echo '<h1 class="welcome-name" style="font-size:1.8rem;">Manifest #'.$m['id'].'</h1>';
                echo '<table class="dataTable" style="width:100%; border-collapse:collapse;">';
                echo '<tr><th style="text-align:left; padding:6px 10px;">Schip</th><td style="padding:6px 10px;">'.htmlspecialchars($m['ship']).'</td></tr>';
                echo '<tr><th style="text-align:left; padding:6px 10px;">Rederij</th><td style="padding:6px 10px;">'.htmlspecialchars($m['company']).'</td></tr>';
                echo '<tr><th style="text-align:left; padding:6px 10px;">Lading</th><td style="padding:6px 10px;">'.htmlspecialchars($m['cargo']).'</td></tr>';
                echo '<tr><th style="text-align:left; padding:6px 10px;">Ontvangen</th><td style="padding:6px 10px;"><code>'.$m['received'].'</code></td></tr>';
                echo '<tr><th style="text-align:left; padding:6px 10px;">Status</th><td style="padding:6px 10px;">'.htmlspecialchars($m['status']).'</td></tr>';
                echo '<tr><th style="text-align:left; padding:6px 10px;">Interne notitie</th><td style="padding:6px 10px;">'.htmlspecialchars($m['notes']).'</td></tr>';
                echo '</table>';
            } else {
                echo '<p>Geen manifest gevonden voor dit nummer.</p>';
            }
            echo '<p style="margin-top:1.5rem;"><a href="manifest.php">&larr; Alle manifesten</a></p>';
        } else {
            echo '<h1 class="welcome-name" style="font-size:1.8rem;">Manifesten</h1>';
            echo '<table class="dataTable" style="width:100%; border-collapse:collapse;">';
            echo '<thead><tr><th style="padding:6px 10px;">Nr</th><th style="padding:6px 10px;">Schip</th><th style="padding:6px 10px;">Rederij</th><th style="padding:6px 10px;">Status</th><th></th></tr></thead><tbody>';
            $res = mysqli_query($conn, "SELECT id,ship,company,status FROM manifests ORDER BY id DESC");
            while ($m = mysqli_fetch_assoc($res)) {
                echo '<tr><td style="padding:6px 10px;"><code>#'.$m['id'].'</code></td>'
                   . '<td style="padding:6px 10px;">'.htmlspecialchars($m['ship']).'</td>'
                   . '<td style="padding:6px 10px;">'.htmlspecialchars($m['company']).'</td>'
                   . '<td style="padding:6px 10px;">'.htmlspecialchars($m['status']).'</td>'
                   . '<td style="padding:6px 10px;"><a href="manifest.php?id='.$m['id'].'">Bekijken</a></td></tr>';
            }
            echo '</tbody></table>';
        }
        ?>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
