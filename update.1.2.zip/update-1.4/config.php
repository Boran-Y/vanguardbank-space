<?php
/* ============================================================
 * Cybertron Port Authority - databaseconfiguratie
 * OPZETTELIJK KWETSBARE TRAININGSMACHINE - ALLEEN IN HET LAB.
 * Niet op het internet plaatsen.
 * (Aanrader voor later: maak een aparte db-gebruiker i.p.v. root.)
 * ============================================================ */
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project-vanguard-space";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Verbinding mislukt: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?>
