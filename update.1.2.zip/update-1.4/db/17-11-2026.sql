-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2026 at 11:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project-vanguard-space`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'Tunahan', 'admin@gmail.com', '202cb962ac59075b964b07152d234b70', '2024-12-06 10:04:51');

-- --------------------------------------------------------

--
-- Table structure for table `bezoeker`
--

CREATE TABLE `bezoeker` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bezoeker`
--

INSERT INTO `bezoeker` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'Gerard', '10096267@student.talland.nl', '202cb962ac59075b964b07152d234b70', '2025-04-07 08:48:13'),
(2, 'Omer', 'Omer@gmail.com', '202cb962ac59075b964b07152d234b70', '2025-04-07 09:45:55'),
(3, 'admin', 'lol123@student.talland.nl', '202cb962ac59075b964b07152d234b70', '2026-11-17 10:34:17');

-- --------------------------------------------------------

--
-- Table structure for table `docks`
--

CREATE TABLE `docks` (
  `id` int(11) NOT NULL,
  `code` varchar(8) NOT NULL,
  `ship` varchar(60) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `crane` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `docks`
--

INSERT INTO `docks` (`id`, `code`, `ship`, `status`, `crane`) VALUES
(1, 'D1', 'MV Iron Tide', 'gelost', 'K2'),
(2, 'D2', NULL, 'leeg', NULL),
(3, 'D3', 'CF Nightjar', 'inspectie', 'K4'),
(4, 'D4', NULL, 'buiten gebruik', NULL),
(5, 'D5', 'Vega Hauler', 'laden', 'K1'),
(6, 'D6', NULL, 'leeg', NULL),
(7, 'D7', NULL, 'leeg', NULL),
(8, 'D8', NULL, 'leeg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `filename` varchar(120) NOT NULL,
  `uploaded_by` varchar(50) NOT NULL,
  `uploaded_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `filename`, `uploaded_by`, `uploaded_at`) VALUES
(1, 'douaneverklaring_1041.pdf', 'agent.dekker', '2017-03-09'),
(2, 'inspectie_D3.pdf', 'agent.reyes', '2017-03-11'),
(3, 'vrachtbrief_1043.pdf', 'cybertron.freight', '2017-03-11');

-- --------------------------------------------------------

--
-- Table structure for table `manifests`
--

CREATE TABLE `manifests` (
  `id` int(11) NOT NULL,
  `ship` varchar(60) NOT NULL,
  `company` varchar(60) NOT NULL,
  `cargo` varchar(120) NOT NULL,
  `received` date NOT NULL,
  `status` varchar(20) NOT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `manifests`
--

INSERT INTO `manifests` (`id`, `ship`, `company`, `cargo`, `received`, `status`, `notes`) VALUES
(1041, 'MV Iron Tide', 'Helix Shipping', 'Machineonderdelen', '2017-03-09', 'goedgekeurd', 'Routinecontrole, niets bijzonders.'),
(1042, 'Vega Hauler', 'Orion Lines', 'Voedselrantsoenen', '2017-03-10', 'goedgekeurd', 'Akkoord.'),
(1043, 'CF Nightjar', 'Cybertron Freight', '\"Landbouwmachines\"', '2017-03-11', 'in controle', 'Gewicht klopt niet met de opgave. Lading apart gezet. Vraag de gebruikersexport op in Beheer voor contact met de beheerder.'),
(1044, 'CF Nightjar', 'Cybertron Freight', 'Reserveonderdelen', '2017-03-11', 'in controle', 'Zelfde rederij, zelfde dag. Verdacht patroon.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  `full_name` varchar(80) NOT NULL,
  `last_login` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `full_name`, `last_login`) VALUES
(1, 'agent.reyes', '883fed93487cb4d257909bdbbfe3cad1', 'douane', 'Agent M. Reyes', '2017-03-14'),
(2, 'agent.dekker', '02bd06bb10bf7ec09d07387deb224380', 'douane', 'Agent J. Dekker', '2017-03-12'),
(3, 'beheer_ext', '725d67c6060d549367b7da410ae79e68', 'beheer', 'Extern Beheer', '2017-03-14'),
(4, 'cybertron.freight', '239ce8ff3be20ac3e2e0e81fbb25bba9', 'rederij', 'Cybertron Freight BV', '2017-03-11'),
(5, 'admin', '123', 'douane', 'admin123', '2026-11-17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `bezoeker`
--
ALTER TABLE `bezoeker`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `docks`
--
ALTER TABLE `docks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manifests`
--
ALTER TABLE `manifests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bezoeker`
--
ALTER TABLE `bezoeker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `docks`
--
ALTER TABLE `docks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `manifests`
--
ALTER TABLE `manifests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1045;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
