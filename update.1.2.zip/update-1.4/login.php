<?php include "login-code.php"; ?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <title>Obsidian Watch &middot; Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="./css/LR.css">
    <link rel="stylesheet" type="text/css" href="./css/navbar.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css">
</head>
<body>
    <?php include "header.php"; ?>
    <div class="container2">
        <form action="login.php" method="POST" class="login-email2">
            <a><img class="logo-styling" src="./fotos/emblem.png"></a>
            <?php if (isset($error)) { ?>
            <div class="error-msg"><?php echo $error; ?></div>
            <?php } ?>
            <div class="input-group2">
                <input id="inputplace" type="email" placeholder="E-mailadres" name="email" required>
            </div>
            <div class="input-group2">
                <input id="inputplace" type="password" placeholder="Wachtwoord" name="password" required>
            </div>
            <div class="input-group2">
                <button name="submit" class="btn2">Login</button>
            </div>
            <p class="login-register-text">Heb je geen account? <a href="register.php">Registreer hier</a>.</p>
        </form>
        <p style="text-align:center; margin-top:1.5rem; font-size:0.8rem; color:var(--textkleur);">
            Systeem v2.3.1 &middot; build 2017-03 &middot; Laatste onderhoud: 14-03-2017
        </p>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
