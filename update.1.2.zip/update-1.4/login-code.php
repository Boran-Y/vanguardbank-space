<?php
session_start();
include 'config.php';

if (isset($_SESSION['email'])) { header("Location: index.php"); exit; }

if (isset($_POST['submit'])) {
    // [KWETSBAARHEID #2 - SQL-injectie / A03 Injection]
    // Het e-mailveld gaat ONGEFILTERD in de query (geen mysqli_real_escape_string).
    // Daardoor is de login te omzeilen, bijv. met e-mailadres:  ' OR '1'='1' --
    // Dit is de bedoelde zwakte voor vlag 2. Niet 'verbeteren'.
    $email    = $_POST['email'];
    $password = md5($_POST['password']);

    // Eerst admin (haven/douane), daarna bezoeker (rederijen).
    $admin_query  = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
    $admin_result = mysqli_query($conn, $admin_query);

    if ($admin_result && mysqli_num_rows($admin_result) >= 1) {
        $row = mysqli_fetch_assoc($admin_result);
        $_SESSION['id']    = $row['id'];
        $_SESSION['name']  = $row['name'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['role']  = 'admin';
        header("Location: index.php");
        exit;
    }

    $bezoeker_query  = "SELECT * FROM bezoeker WHERE email = '$email' AND password = '$password'";
    $bezoeker_result = mysqli_query($conn, $bezoeker_query);

    if ($bezoeker_result && mysqli_num_rows($bezoeker_result) >= 1) {
        $row = mysqli_fetch_assoc($bezoeker_result);
        $_SESSION['id']    = $row['id'];
        $_SESSION['name']  = $row['name'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['role']  = 'bezoeker';
        header("Location: index.php");
        exit;
    }

    $error = "Onjuist e-mailadres of wachtwoord. Probeer opnieuw.";
}
?>
