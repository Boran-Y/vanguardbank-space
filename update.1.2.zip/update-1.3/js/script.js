document.getElementById('appointmentForm').addEventListener('submit', function (event) {
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;

    if (!date || !time) {
        alert('Zorg ervoor dat alle velden correct zijn ingevuld.');
        event.preventDefault();
    }
});

// Haal elementen op
const modal = document.getElementById('modal');
const modalMessage = document.getElementById('modal-message');
const closeModal = document.getElementById('close-modal');

// Functie om modal te tonen
function showModal(message) {
    modalMessage.textContent = message; // Stel het bericht in
    modal.style.display = 'block'; // Toon de modal
}

// Sluit modal bij klik op sluitknop
closeModal.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Sluit modal bij klik buiten de inhoud
window.addEventListener('click', (event) => {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});

