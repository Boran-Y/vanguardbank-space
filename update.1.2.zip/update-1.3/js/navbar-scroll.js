// Navbar: krimpt in en krijgt een achtergrond/blur zodra er gescrold wordt.
// Werkt op elke schermbreedte (mobiel en desktop).
(function () {
  var nav = document.getElementById('mainNav');
  if (!nav) return;

  var SCROLL_THRESHOLD = 40; // pixels voordat de balk omdraait
  var isShrunk = false;

  function updateNavbar() {
    var shouldShrink = window.scrollY > SCROLL_THRESHOLD;

    if (shouldShrink === isShrunk) return;
    isShrunk = shouldShrink;

    nav.classList.toggle('navbar-shrink', isShrunk);
  }

  window.addEventListener('scroll', updateNavbar, { passive: true });
  document.addEventListener('DOMContentLoaded', updateNavbar);
  updateNavbar(); // meteen checken, voor het geval de pagina al gescrold is geladen
})();