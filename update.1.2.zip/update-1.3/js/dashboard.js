$(document).ready(function() {
    $('#appointmentsTable').DataTable({
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "responsive": true
    });
});


function openUpdateModal(id) {

    $.ajax({
        url: './afspraken/fetch_afspraken.php',
        type: 'GET',
        data: {
            id: id
        },
        success: function(response) {
            const data = JSON.parse(response);
            $('#appointmentId').val(data.id);
            $('#name').val(data.name);
            $('#service').val(data.service);
            $('#date').val(data.date);
            $('#time').val(data.time);
            $('#updateModal').modal('show');
        }
    });
}

function updateAppointment() {
    const id = $('#appointmentId').val();
    const name = $('#name').val();
    const service = $('#service').val();
    const date = $('#date').val();
    const time = $('#time').val();

    $.ajax({
        url: './afspraken/update_afspraken.php',
        type: 'POST',
        data: {
            id: id,
            name: name,
            service: service,
            date: date,
            time: time
        },
        success: function(response) {
            console.log(response); 
            if (response === 'success') {
                $('#updateModal').modal('hide');
                location.reload(); 
            } else {
                alert('Fout bij het bijwerken van de afspraak.'); 
            }
        },
        error: function(xhr, status, error) {

            console.error('AJAX-fout:', error);
            alert('Er is een probleem met de verbinding. Probeer het later opnieuw.');
        }
    });
}


function deleteAppointment(id) {
    if (confirm("Weet je zeker dat je de afspraak wilt verwijderen?")) {

        window.location.href = "./afspraken/verwijder_afspraken.php?id=" + id;
    }
}