<?php 
include 'config.php';
error_reporting(0);
session_start();

if (isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

$username = '';

if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if ($password === $cpassword) {

        // Controleer of e-mailadres al bestaat in bezoeker
        $check_query = "SELECT * FROM bezoeker WHERE email = '$email'";
        $check_result = mysqli_query($conn, $check_query);

        if (mysqli_num_rows($check_result) > 0) {
            echo "<script>alert('E-mail bestaat al.');</script>";
        } else {

            // Wachtwoord hashen
            $hashed_password = md5($password);

            // Nieuwe bezoeker toevoegen aan database
            $insert_query = "INSERT INTO bezoeker (name, email, password) 
                             VALUES ('$username', '$email', '$hashed_password')";
            
            $insert_result = mysqli_query($conn, $insert_query);

            if ($insert_result) {
                echo "<script>alert('Registratie is compleet. Klik op OK om verder te gaan.');</script>";
                echo "<script>window.location.href = 'login.php';</script>";
                exit;
            } else {
                echo "<script>alert('Er is iets misgegaan.');</script>";
            }
        }
    } else {
        echo "<script>alert('Wachtwoorden komen niet overeen.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Obsidian Watch · Registreren</title>
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" crossorigin="anonymous" />
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/LR.css">
</head>
<body>

    <?php include "header.php"; ?>

    <div class="container2">
        <form action="" method="POST" class="login-email2">
            <img class="logo-styling" src="./fotos/logo.png">

            <div class="input-group2">
                <input id="inputplace" type="text" placeholder="Gebruikersnaam" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
            </div>

            <div class="input-group2">
                <input id="inputplace" type="email" placeholder="Email" name="email" value="<?php echo htmlspecialchars($email ?? ''); ?>" required>
            </div>

            <div class="input-group2">
                <input id="inputplace" type="password" placeholder="Wachtwoord" name="password" required>
            </div>

            <div class="input-group2">
                <input id="inputplace" type="password" placeholder="Wachtwoord bevestigen" name="cpassword" required>
            </div>

            <div class="input-group2">
                <button style="color:#fff;" id="inputplace" name="submit" class="btn2">Registreer</button>
            </div>

            <p class="login-register-text">
                Heb je al een account? <a href="login.php">Log hier</a> in.
            </p>
        </form>
    </div>

    <script src="./js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>