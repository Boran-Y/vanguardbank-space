<?php
// Databaseconfiguratie
$servername = "localhost:3306"; 
$username = "root"; 
$password = ""; 
$dbname = "project-vanguard-space"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    
    die("Verbinding mislukt: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4"); 
?>
