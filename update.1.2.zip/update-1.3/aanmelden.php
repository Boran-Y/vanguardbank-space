<?php
session_start();

// Publieke pagina: geen login nodig.
// Dit is stap 1 van het pad naar vlag 1: de aanvaller ontdekt hier dat de
// haven manifesten via FTP aanneemt (poort 21, map /manifests).
$ftp_host = $_SERVER['SERVER_NAME'] ?? 'cybertron-port';
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Obsidian Watch · Lading aanmelden</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body style="height:auto; min-height:100vh; align-items:flex-start; padding-top:9rem; padding-bottom:3rem;">

    <!-- Headerbestand toevoegen -->
    <?php include "header.php"; ?>

    <main style="width:100%; max-width:760px; margin:0 auto; padding:0 1rem;">

        <!-- Zelfde kaartstijl als container1 uit style.css, hergebruikt voor deze pagina -->
        <div class="container1" style="width:100%; margin-top:0;">

            <h1 class="welcome-name" style="font-size:2rem; color:var(--textkleur);">Lading aanmelden</h1>
            <p style="text-align:center; color:var(--textkleur);">
                Cybertron Port Authority &middot; Douanepost
            </p>

            <p style="margin-top:1.2rem;">
                Elk schip dat Cybertron aandoet, meldt v&oacute;&oacute;r aankomst zijn lading aan bij de douane.
                Rederijen leveren hun scheepsmanifest automatisch aan via de FTP-server van de haven.
                Een douane-agent controleert het manifest daarna in het havenbesturingssysteem.
            </p>

            <!-- Stap 1 -->
            <div style="margin-top:1.5rem;">
                <label>Stap 1 &middot; Manifest klaarmaken</label>
                <p>
                    Maak een tekstbestand met schip, rederij, lading en verwachte aankomst.
                    Gebruik als bestandsnaam <code>manifest_&lt;nummer&gt;.txt</code>,
                    bijvoorbeeld <code>manifest_1041.txt</code>.
                </p>
            </div>

            <!-- Stap 2 -->
            <div style="margin-top:1rem;">
                <label>Stap 2 &middot; Aanleveren via FTP</label>
                <p>
                    Plaats het bestand in de map <code>/manifests</code> op de FTP-server van de haven.
                    Voor automatische aanlevering is geen aparte aanvraag van inloggegevens nodig.
                </p>
                <table class="dataTable" style="width:100%; border-collapse:collapse; margin-bottom:1rem;">
                    <tbody>
                        <tr>
                            <th style="text-align:left; padding:6px 10px; color:var(--textkleur) !important;">Server</th>
                            <td style="padding:6px 10px;"><code><?php echo htmlspecialchars($ftp_host); ?></code></td>
                        </tr>
                        <tr>
                            <th style="text-align:left; padding:6px 10px; color:var(--textkleur) !important;">Poort</th>
                            <td style="padding:6px 10px;"><code>21</code></td>
                        </tr>
                        <tr>
                            <th style="text-align:left; padding:6px 10px; color:var(--textkleur) !important;">Map</th>
                            <td style="padding:6px 10px;"><code>/manifests</code></td>
                        </tr>
                        <tr>
                            <th style="text-align:left; padding:6px 10px; color:var(--textkleur) !important;">Verwerking</th>
                            <td style="padding:6px 10px;">Automatisch</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Stap 3 -->
            <div style="margin-top:1rem;">
                <label>Stap 3 &middot; Controle door de douane</label>
                <p>
                    Een douane-agent keurt het manifest goed of zet het in controle.
                    De status ziet u terug in het havenbesturingssysteem.
                </p>
                <a href="login.php" class="confirm-btn" style="display:inline-block; text-decoration:none; text-align:center;">
                    Naar het havenbesturingssysteem
                </a>
            </div>

            <!-- Recent ontvangen manifesten -->
            <div style="margin-top:2rem;">
                <label>Recent ontvangen manifesten</label>
                <table class="dataTable" style="width:100%; border-collapse:collapse;">
                    <thead>
                        <tr>
                            <th style="padding:6px 10px;">Nr</th>
                            <th style="padding:6px 10px;">Schip</th>
                            <th style="padding:6px 10px;">Rederij</th>
                            <th style="padding:6px 10px;">Ontvangen</th>
                            <th style="padding:6px 10px;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="padding:6px 10px;"><code>#1041</code></td>
                            <td style="padding:6px 10px;">MV Iron Tide</td>
                            <td style="padding:6px 10px;">Helix Shipping</td>
                            <td style="padding:6px 10px;"><code>09-03-2017</code></td>
                            <td style="padding:6px 10px;">Goedgekeurd</td>
                        </tr>
                        <tr>
                            <td style="padding:6px 10px;"><code>#1042</code></td>
                            <td style="padding:6px 10px;">Vega Hauler</td>
                            <td style="padding:6px 10px;">Orion Lines</td>
                            <td style="padding:6px 10px;"><code>10-03-2017</code></td>
                            <td style="padding:6px 10px;">Goedgekeurd</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <p style="text-align:center; margin-top:2rem; font-size:0.8rem; color:var(--textkleur);">
                Systeem v2.3.1 &middot; build 2017-03 &middot; Laatste onderhoud: 14-03-2017
            </p>

        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
