<header>
    <!-- ========= NAVBAR BEGIN =======-->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand text-white" href="index.php#home">
                <img src="./fotos/logo-inverted.png" alt="Obsidian Watch">
                <em class="navbar-logo-text"></em>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <label class="burger" for="burger">
                    <input id="burger" type="checkbox">
                    <span></span>
                    <span></span>
                    <span></span>
                </label>
            </button>

            <div class="collapse navbar-collapse" id="navbarResponsive">
                <!-- Midden: navigatielinks -->
                <ul class="navbar-nav mx-auto py-2 py-lg-0 align-items-lg-center">
                    <?php 
                    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { 
                        echo '<li class="nav-item"><a class="nav-link" href="aanmelden.php">isdit</a></li>';
                    } elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'student') { 
                        echo '<li class="nav-item"><a></a></li>';
                    }
                    ?>
                </ul>

                <ul class="navbar-nav mx-auto py-2 py-lg-0 align-items-lg-center">
                    <?php 
                    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { 
                        echo '<li class="nav-item"><a class="nav-link" href="aanmelden.php">mooigedaan</a></li>';
                    } elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'student') { 
                        echo '<li class="nav-item"><a></a></li>';
                    }
                    ?>

                </ul>

                                <ul class="navbar-nav mx-auto py-2 py-lg-0 align-items-lg-center">
                    <?php 
                    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { 
                        echo '<li class="nav-item"><a class="nav-link" href="aanmelden.php">ofniet</a></li>';
                    } elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'student') { 
                        echo '<li class="nav-item"><a></a></li>';
                    }
                    ?>
                </ul>

                <!-- Rechts: Login / Uitloggen -->
                <ul class="navbar-nav py-2 py-lg-0 align-items-lg-center">
                    <?php
                    if (isset($_SESSION['name'])) {  
                        echo '<li class="nav-item">
                            <div class="main-button">
                                <a href="./logout.php">Uitloggen <i class="fa-solid fa-arrow-right-from-bracket loguit-knop"></i></a>
                            </div>
                        </li>';
                    } else {
                        echo '<li class="nav-item">
                            <div class="main-button">
                                <a href="./login.php">Login <i class="fa-solid fa-right-to-bracket login-knop"></i></a>
                            </div>
                        </li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </nav>
    <!-- ========= NAVBAR EINDE =======-->
</header>
<script src="./js/navbar-scroll.js" defer></script>