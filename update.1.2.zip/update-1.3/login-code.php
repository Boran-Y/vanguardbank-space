
<?php
session_start(); 
include 'config.php'; 

if (isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']); 
    $password = md5($_POST['password']);

    // Check admin table
    $admin_query = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
    $admin_result = mysqli_query($conn, $admin_query);

    if (mysqli_num_rows($admin_result) === 1) {
        $row = mysqli_fetch_assoc($admin_result);
        $_SESSION['id'] = $row['id'];
        $_SESSION['name'] = $row['name'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['role'] = 'admin';
        header("Location: index.php");
        exit;
    }

    // Check bezoeker table
    $bezoeker_query = "SELECT * FROM bezoeker WHERE email = '$email' AND password = '$password'";
    $bezoeker_result = mysqli_query($conn, $bezoeker_query);

    if (mysqli_num_rows($bezoeker_result) === 1) {
        $row = mysqli_fetch_assoc($bezoeker_result);
        $_SESSION['id'] = $row['id'];
        $_SESSION['name'] = $row['name'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['role'] = 'bezoeker';
        header("Location: index.php");
        exit;
    }

    $error = "Onjuiste e-mailadres of wachtwoord. Probeer opnieuw.";
}
?>
