<?php 
session_start(); 
?>

<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Obsidian Watch · Home</title>
    <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/navbar.css">
</head>

<body>

    <!-- Headerbestand toevoegen -->
    <?php include "header.php";?>

    <div>
        <?php 
        if (isset($_SESSION['name'])) {
            $name =$_SESSION['name']; 
            $role =$_SESSION['role'] === 'admin' ? 'Admin' : 'Bezoeker'; 

            echo '<h1 class="welcome-name">Welkom, ' . htmlspecialchars($name) . '!</h1>';
            echo '<h2 class="user-role">Je bent een ' . $role . '</h2>';
        } else {
            echo '<h1 class="welcome-name">Je bent niet ingelogd!</h1>';
            echo '<p class="user-role">Om verder te gaan, <a href="login.php" class="login-link">log hier in</a>.</p>';
        }
        ?>
    </div>

    <script src="./js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>