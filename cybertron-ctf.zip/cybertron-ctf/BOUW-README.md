# Cybertron Port Authority - bouw- en kwetsbaarhedenoverzicht

> **ALLEEN VOOR HET LAB.** Deze code is opzettelijk kwetsbaar. Zet hem
> uitsluitend op de geisoleerde VM en de prive TryHackMe-room. Nooit op
> het echte internet, en nooit met echte persoonsgegevens.

## Wat zit erin
Dit pakket vervangt het oude `admin`/`bezoeker`-deel door het
havenbesturingssysteem uit jullie ontwerp, met de kwetsbaarheden ingebouwd.

| Bestand | Rol |
|---|---|
| `db/cybertron.sql` | Database `cybertron_port`: users, docks, manifests, documents + nepdata |
| `config.php` | Verbinding met een aparte db-gebruiker (geen root) |
| `login.php` / `login-code.php` | Inloggen op gebruikersnaam |
| `dashboard.php` | Dashboard na login; hier staat vlag 2 |
| `manifest.php` | Manifest bekijken op id |
| `beheer.php` | Gebruikersexport met de hashes |
| `upload.php` | Document uploaden |
| `header.php` | Navigatie, omgedoopt naar Cybertron Port Authority |
| `inc/auth.php` | Sessiebewaking |
| `ftp/manifests/` | Bestanden voor de FTP-server (vlag 1) |
| `dwaalspoor/backup_2017.zip` | Decoy voor de SMB-share |

## De kwetsbaarheden en waar ze zitten

| # | Kwetsbaarheid | Bestand | Op winnend pad |
|---|---|---|---|
| 1 | Anonieme FTP | server (vsftpd) | ja - vlag 1 |
| 2 | SQL-injectie in login | `login-code.php` | ja - vlag 2 |
| 3 | IDOR op manifesten | `manifest.php` | ja - vlag 2 |
| 4 | Ongezouten MD5-hash | `db/cybertron.sql`, `beheer.php` | ja - vlag 3 |
| 5 | Hergebruik wachtwoord SSH | server + db | ja - vlag 3 |
| 6 | Upload zonder controle | `upload.php` | nee |
| 7 | SMB-share leesbaar (dwaalspoor) | server (Samba) | nee |
| 8 | Verouderde versies | Ubuntu 16.04 stack | nee |

Elke kwetsbaarheid is in de code gemarkeerd met een comment `[KWETSBAARHEID #n ...]`.
Laat die comments eruit voordat de room naar een andere crew gaat als de docent
dat wil - of laat ze staan voor je eigen bouwdossier.

## Winnend pad (ter controle)
1. **Vlag 1** - FTP (poort 21) staat anonymous aan. In `/manifests` staat
   `_archief_oud.txt` met vlag 1 en de hint naar de webserver.
2. **Vlag 2** - Login omzeilen via SQL-injectie in het veld gebruikersnaam
   (het veld gaat ongefilterd in de query). Als beheerder verschijnt vlag 2
   op het dashboard. Via `manifest.php?id=1043` (IDOR) vind je het verdachte
   Cybertron Freight-manifest met de hint naar Beheer, en in `beheer.php`
   de gebruikersexport met de hashes.
3. **Vlag 3** - De MD5-hash van `beheer_ext` is `starlight` (staat in rockyou).
   Zelfde wachtwoord als voor SSH. Inloggen via SSH en vlag 3 ophalen.

## Flags
De flags staan als placeholder `THM{VERVANG_DIT_...}`. Zet jullie eigen waarden:
- Vlag 1: `ftp/manifests/_archief_oud.txt`
- Vlag 2: `dashboard.php`
- Vlag 3: zelf aanmaken als bestand op de VM, bv. `/home/beheer_ext/flag3.txt`

## Wachtwoorden (MD5, geen salt)
| Gebruiker | Wachtwoord | Opmerking |
|---|---|---|
| agent.reyes | `R3yes!harbor#71` | sterk |
| agent.dekker | `Dekk3r$dock#44` | sterk |
| cybertron.freight | `Fr8ght!Cyb#2017` | sterk |
| beheer_ext | `starlight` | **crackbaar** (rockyou); zet dit ook als SSH-wachtwoord |

Alleen `beheer_ext` hoort crackbaar te zijn. Wil je een ander crackbaar
wachtwoord, kies er een uit rockyou, pas de hash in `cybertron.sql` aan
(MD5, geen salt) en zet hetzelfde wachtwoord op het Linux-account.

## Opzetten op de VM (Ubuntu 16.04)
```
sudo apt install apache2 php libapache2-mod-php php-mysql mysql-server vsftpd samba openssh-server
sudo mysql < db/cybertron.sql
# db-gebruiker aanmaken (zie bovenin config.php)
sudo cp -r *.php css fotos js inc /var/www/html/
```
- **FTP (#1):** zet in vsftpd `anonymous_enable=YES`, deel `/manifests`, plaats de bestanden uit `ftp/manifests/`.
- **SMB (#7):** deel een map met `backup_2017.zip`, leesbaar zonder inlog.
- **SSH (#5):** maak het account `beheer_ext` met wachtwoord `starlight`, plaats vlag 3 in de home-map.
- **Verwijder** de map `.git` voordat je naar `/var/www/html` kopieert.

## Nog doen (klopt nog niet met het ontwerp)
- `register.php` verwijderen (open registratie staat niet in het ontwerp).
- Bootstrap en Font Awesome lokaal plaatsen (TryHackMe-machine heeft vaak geen internet).
- `js/dashboard.js` (oude afsprakencode) en de rol `student` weghalen.
