<?php
session_start();
include 'config.php';

if (isset($_SESSION['username'])) { header("Location: dashboard.php"); exit; }

if (isset($_POST['submit'])) {
    $user = $_POST['username'];
    $pass = md5($_POST['password']);

    // [KWETSBAARHEID #2 - SQL-injectie / A03 Injection]
    // De gebruikersnaam gaat ONGEFILTERD in de query. Daardoor is de login
    // te omzeilen, bijv. met gebruikersnaam:  ' OR '1'='1' --
    // (Dit is de bedoelde zwakte voor vlag 2. Niet 'verbeteren'.)
    $query  = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) >= 1) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['id']       = $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['role']     = $row['role'];
        $_SESSION['full_name']= $row['full_name'];
        header("Location: dashboard.php");
        exit;
    }
    $error = "Onjuiste gebruikersnaam of wachtwoord.";
}
?>
