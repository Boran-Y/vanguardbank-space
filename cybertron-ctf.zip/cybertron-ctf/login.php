<?php include 'login-code.php'; ?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cybertron Port Authority &middot; Inloggen</title>
  <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="./css/LR.css">
  <link rel="stylesheet" href="./css/navbar.css">
  <link rel="stylesheet" href="./css/style.css">
</head>
<body>
  <?php include "header.php"; ?>
  <div class="container2">
    <form action="login.php" method="POST" class="login-email2">
      <img class="logo-styling" src="./fotos/emblem.png" alt="Cybertron Port Authority">
      <p style="text-align:center;letter-spacing:2px;font-size:.8rem;">CYBERTRON PORT AUTHORITY &middot; HAVENBESTURING</p>
      <?php if (isset($error)) { ?><div class="error-msg"><?php echo $error; ?></div><?php } ?>
      <div class="input-group2">
        <input id="inputplace" type="text" placeholder="Gebruikersnaam (bijv. agent.naam)" name="username" required>
      </div>
      <div class="input-group2">
        <input id="inputplace" type="password" placeholder="Wachtwoord" name="password" required>
      </div>
      <div class="input-group2">
        <button name="submit" class="btn2">Inloggen</button>
      </div>
      <p class="login-register-text" style="font-size:.75rem;">Systeem v2.3.1 &middot; build 2017-03 &middot; Laatste onderhoud: 14-03-2017</p>
    </form>
  </div>
</body>
</html>
