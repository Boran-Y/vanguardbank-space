<?php include 'inc/auth.php'; include 'config.php'; ?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Havenbesturing &middot; Dashboard</title>
  <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="./css/style.css">
  <link rel="stylesheet" href="./css/navbar.css">
</head>
<body style="height:auto;min-height:100vh;align-items:flex-start;padding-top:9rem;">
  <?php include "header.php"; ?>
  <main style="width:100%;max-width:960px;margin:0 auto;padding:0 1rem;">
    <div class="container1" style="width:100%;margin-top:0;">
      <h1 class="welcome-name">Goedemorgen, <?php echo htmlspecialchars($_SESSION['full_name']); ?></h1>
      <p class="user-role">Rol: <?php echo htmlspecialchars($_SESSION['role']); ?> &middot; 3 schepen aangemeld, 2 manifesten in controle</p>

      <!-- [VLAG 2] Zichtbaar zodra je als beheerder binnen bent (via de SQLi-login). -->
      <?php if ($_SESSION['role'] === 'beheer') { ?>
        <p style="font-family:monospace;color:#8B7CF0;">Systeemsleutel: THM{VERVANG_DIT_VLAG_2}</p>
      <?php } ?>

      <h2 style="margin-top:2rem;">Recente manifesten</h2>
      <table class="dataTable" style="width:100%;border-collapse:collapse;">
        <thead><tr><th>Nr</th><th>Schip</th><th>Rederij</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php
        $res = mysqli_query($conn, "SELECT id,ship,company,status FROM manifests ORDER BY id DESC");
        while ($m = mysqli_fetch_assoc($res)) {
            echo '<tr>'
               . '<td><code>#'.$m['id'].'</code></td>'
               . '<td>'.htmlspecialchars($m['ship']).'</td>'
               . '<td>'.htmlspecialchars($m['company']).'</td>'
               . '<td>'.htmlspecialchars($m['status']).'</td>'
               . '<td><a href="manifest.php?id='.$m['id'].'">Bekijken</a></td></tr>';
        }
        ?>
        </tbody>
      </table>
      <p style="margin-top:1.5rem;"><a href="beheer.php">Beheer</a> &middot; <a href="upload.php">Documenten</a> &middot; <a href="logout.php">Uitloggen</a></p>
    </div>
  </main>
</body>
</html>
