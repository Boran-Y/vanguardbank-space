<?php include 'inc/auth.php'; include 'config.php';
// Export van gebruikers. Toont ook de wachtwoordhashes ([#4] ongezouten MD5),
// waaronder die van beheer_ext. Dat is de hint naar vlag 3: hash kraken en
// via SSH inloggen ([#5] hergebruikt wachtwoord).
$res = mysqli_query($conn, "SELECT username,password,role,last_login FROM users");
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Beheer &middot; Gebruikers</title>
  <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="./css/style.css"><link rel="stylesheet" href="./css/navbar.css">
</head>
<body style="height:auto;min-height:100vh;align-items:flex-start;padding-top:9rem;">
  <?php include "header.php"; ?>
  <main style="width:100%;max-width:820px;margin:0 auto;padding:0 1rem;">
    <div class="container1" style="width:100%;margin-top:0;">
      <h1 class="welcome-name" style="font-size:1.8rem;">Gebruikersexport</h1>
      <table class="dataTable" style="width:100%;border-collapse:collapse;">
        <thead><tr><th>Gebruiker</th><th>Wachtwoord (hash)</th><th>Rol</th><th>Laatst ingelogd</th></tr></thead>
        <tbody>
        <?php while ($u = mysqli_fetch_assoc($res)) {
          echo '<tr><td>'.htmlspecialchars($u['username']).'</td>'
             . '<td><code>'.$u['password'].'</code></td>'
             . '<td>'.htmlspecialchars($u['role']).'</td>'
             . '<td><code>'.$u['last_login'].'</code></td></tr>';
        } ?>
        </tbody>
      </table>
      <p style="margin-top:1.5rem;"><a href="dashboard.php">&larr; Terug naar dashboard</a></p>
    </div>
  </main>
</body>
</html>
