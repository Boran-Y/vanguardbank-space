-- ============================================================
-- Cybertron Port Authority - Havenbesturing (v2.3.1, 2017)
-- OPZETTELIJK KWETSBARE TRAININGSDATABASE
-- Alleen voor de geisoleerde lab-VM / prive TryHackMe-room.
-- NOOIT op het internet plaatsen.
-- ============================================================
CREATE DATABASE IF NOT EXISTS `cybertron_port` DEFAULT CHARSET=utf8mb4;
USE `cybertron_port`;

CREATE TABLE `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL,   -- [KWETSBAARHEID #4] ongezouten MD5
  `role` VARCHAR(20) NOT NULL,        -- douane | beheer | rederij
  `full_name` VARCHAR(80) NOT NULL,
  `last_login` DATE DEFAULT NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Wachtwoorden (MD5, geen salt):
--   agent.reyes        = R3yes!harbor#71   (sterk)
--   agent.dekker       = Dekk3r$dock#44    (sterk)
--   cybertron.freight  = Fr8ght!Cyb#2017   (sterk)
--   beheer_ext         = starlight         ([#4] crackbaar met rockyou; [#5] ook het SSH-wachtwoord)
INSERT INTO `users` (`username`,`password`,`role`,`full_name`,`last_login`) VALUES
('agent.reyes','883fed93487cb4d257909bdbbfe3cad1','douane','Agent M. Reyes','2017-03-14'),
('agent.dekker','02bd06bb10bf7ec09d07387deb224380','douane','Agent J. Dekker','2017-03-12'),
('beheer_ext','725d67c6060d549367b7da410ae79e68','beheer','Extern Beheer','2017-03-14'),
('cybertron.freight','239ce8ff3be20ac3e2e0e81fbb25bba9','rederij','Cybertron Freight BV','2017-03-11');

CREATE TABLE `docks` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(8) NOT NULL,
  `ship` VARCHAR(60) DEFAULT NULL,
  `status` VARCHAR(20) NOT NULL,
  `crane` VARCHAR(8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `docks` (`code`,`ship`,`status`,`crane`) VALUES
('D1','MV Iron Tide','gelost','K2'),('D2',NULL,'leeg',NULL),
('D3','CF Nightjar','inspectie','K4'),('D4',NULL,'buiten gebruik',NULL),
('D5','Vega Hauler','laden','K1'),('D6',NULL,'leeg',NULL),
('D7',NULL,'leeg',NULL),('D8',NULL,'leeg',NULL);

CREATE TABLE `manifests` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `ship` VARCHAR(60) NOT NULL,
  `company` VARCHAR(60) NOT NULL,
  `cargo` VARCHAR(120) NOT NULL,
  `received` DATE NOT NULL,
  `status` VARCHAR(20) NOT NULL,
  `notes` TEXT,                       -- interne notitie, zichtbaar via [#3] IDOR
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1041;
INSERT INTO `manifests` (`ship`,`company`,`cargo`,`received`,`status`,`notes`) VALUES
('MV Iron Tide','Helix Shipping','Machineonderdelen','2017-03-09','goedgekeurd','Routinecontrole, niets bijzonders.'),
('Vega Hauler','Orion Lines','Voedselrantsoenen','2017-03-10','goedgekeurd','Akkoord.'),
('CF Nightjar','Cybertron Freight','\"Landbouwmachines\"','2017-03-11','in controle','Gewicht klopt niet met opgave. Lading apart gezet. Vraag export gebruikers op in Beheer voor contact beheerder.'),
('CF Nightjar','Cybertron Freight','Reserveonderdelen','2017-03-11','in controle','Zelfde rederij, zelfde dag. Verdacht patroon.');

CREATE TABLE `documents` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `filename` VARCHAR(120) NOT NULL,
  `uploaded_by` VARCHAR(50) NOT NULL,
  `uploaded_at` DATE NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `documents` (`filename`,`uploaded_by`,`uploaded_at`) VALUES
('douaneverklaring_1041.pdf','agent.dekker','2017-03-09'),
('inspectie_D3.pdf','agent.reyes','2017-03-11'),
('vrachtbrief_1043.pdf','cybertron.freight','2017-03-11');
