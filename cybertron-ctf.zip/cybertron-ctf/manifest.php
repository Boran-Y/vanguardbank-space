<?php include 'inc/auth.php'; include 'config.php';

// [KWETSBAARHEID #3 - IDOR / A01 Broken Access Control]
// Elk manifest is opvraagbaar op id, zonder controle of deze gebruiker
// het mag zien. Zo vindt de aanvaller het verdachte Cybertron Freight-
// manifest (#1043) en de hint naar de gebruikersexport in Beheer.
$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$res = mysqli_query($conn, "SELECT * FROM manifests WHERE id = $id");
$m   = $res ? mysqli_fetch_assoc($res) : null;
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manifest <?php echo $id ? '#'.$id : ''; ?></title>
  <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="./css/style.css"><link rel="stylesheet" href="./css/navbar.css">
</head>
<body style="height:auto;min-height:100vh;align-items:flex-start;padding-top:9rem;">
  <?php include "header.php"; ?>
  <main style="width:100%;max-width:760px;margin:0 auto;padding:0 1rem;">
    <div class="container1" style="width:100%;margin-top:0;">
      <?php if ($m) { ?>
        <h1 class="welcome-name" style="font-size:1.8rem;">Manifest #<?php echo $m['id']; ?></h1>
        <table class="dataTable" style="width:100%;border-collapse:collapse;">
          <tr><th style="text-align:left;">Schip</th><td><?php echo htmlspecialchars($m['ship']); ?></td></tr>
          <tr><th style="text-align:left;">Rederij</th><td><?php echo htmlspecialchars($m['company']); ?></td></tr>
          <tr><th style="text-align:left;">Lading</th><td><?php echo htmlspecialchars($m['cargo']); ?></td></tr>
          <tr><th style="text-align:left;">Ontvangen</th><td><code><?php echo $m['received']; ?></code></td></tr>
          <tr><th style="text-align:left;">Status</th><td><?php echo htmlspecialchars($m['status']); ?></td></tr>
          <tr><th style="text-align:left;">Interne notitie</th><td><?php echo htmlspecialchars($m['notes']); ?></td></tr>
        </table>
      <?php } else { ?>
        <p>Geen manifest gevonden voor dit nummer.</p>
      <?php } ?>
      <p style="margin-top:1.5rem;"><a href="dashboard.php">&larr; Terug naar dashboard</a></p>
    </div>
  </main>
</body>
</html>
