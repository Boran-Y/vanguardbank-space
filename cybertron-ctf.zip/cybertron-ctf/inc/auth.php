<?php
// Sessiebewaking: stuur niet-ingelogde bezoekers naar de login.
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>
