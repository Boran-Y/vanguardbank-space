# Cybertron - serverinstellingen (FTP, SMB, SSH)

> **ALLEEN VOOR DE LAB-VM.** Deze instellingen zetten services bewust open.
> Nooit op het internet, nooit op een netwerk met echte data.

Doe dit op de Ubuntu 16.04-VM nadat de website en de database draaien
(zie BOUW-README.md). Vlag 1 komt van FTP, vlag 3 van SSH, het dwaalspoor
van SMB.

## 1. FTP - anonieme toegang (kwetsbaarheid #1, vlag 1)
```
sudo apt install vsftpd
sudo mkdir -p /srv/ftp/manifests
sudo cp ftp/manifests/* /srv/ftp/manifests/
sudo chown -R ftp:ftp /srv/ftp
```
Zet in `/etc/vsftpd.conf`:
```
anonymous_enable=YES
anon_root=/srv/ftp
no_anon_password=YES
```
Daarna: `sudo systemctl restart vsftpd`

Controle (vanaf de Kali-VM):
```
ftp <ip-van-de-machine>     # inloggen als 'anonymous', leeg wachtwoord
```
De aanvaller vindt in `/manifests` het bestand `_archief_oud.txt` met vlag 1
en de hint naar de webserver.

## 2. SSH - beheer_ext (kwetsbaarheid #5, vlag 3)
```
sudo adduser beheer_ext          # wachtwoord: starlight (zelfde als in de database)
echo 'THM{VERVANG_DIT_VLAG_3}' | sudo tee /home/beheer_ext/flag3.txt
sudo chown beheer_ext:beheer_ext /home/beheer_ext/flag3.txt
sudo chmod 600 /home/beheer_ext/flag3.txt
```
Zorg dat SSH met wachtwoord mag (`PasswordAuthentication yes` in
`/etc/ssh/sshd_config`), daarna `sudo systemctl restart ssh`.

De aanvaller kraakt de MD5-hash van beheer_ext uit de gebruikersexport
(`starlight` staat in rockyou), logt in via SSH en leest vlag 3.

## 3. SMB - dwaalspoor (kwetsbaarheid #7)
```
sudo apt install samba
sudo mkdir -p /srv/samba/archief
sudo cp dwaalspoor/backup_2017.zip /srv/samba/archief/
```
Voeg onderaan `/etc/samba/smb.conf` toe:
```
[archief]
   path = /srv/samba/archief
   browseable = yes
   read only = yes
   guest ok = yes
```
En zet bovenin bij [global]: `map to guest = Bad User`
Daarna: `sudo systemctl restart smbd`

Controle:
```
smbclient -N -L //<ip>/          # share 'archief' moet zichtbaar zijn
```
De aanvaller vindt `backup_2017.zip`, kan die kraken (wachtwoord `haven2016`),
maar de inloggegevens erin zijn verlopen en werken nergens. Dood spoor.

## 4. Laatste check voor de OVA
- Website bereikbaar op poort 80, inloggen en de SQLi werken.
- FTP, SSH en SMB bereikbaar vanaf de Kali-VM.
- `.git`-map is weg uit `/var/www/html`.
- Alle services starten na een herstart: `sudo systemctl enable apache2 mysql vsftpd smbd ssh`
- Pas daarna exporteren als OVA en testen op TryHackMe.
