<?php include 'inc/auth.php';
$msg = '';
if (isset($_POST['submit']) && isset($_FILES['doc'])) {
    // [KWETSBAARHEID #6 - Upload zonder controle / A04 Insecure Design]
    // Er wordt niet gecontroleerd op bestandstype of extensie, en de map
    // is via het web benaderbaar. Dit is een bewuste neven-zwakte
    // (niet op het winnende pad). Laat de map NOOIT buiten het lab staan.
    $dir = __DIR__ . '/uploads/';
    if (!is_dir($dir)) { mkdir($dir, 0755, true); }
    $name = basename($_FILES['doc']['name']);
    if (move_uploaded_file($_FILES['doc']['tmp_name'], $dir . $name)) {
        $msg = 'Document opgeslagen: ' . htmlspecialchars($name);
    } else {
        $msg = 'Upload mislukt.';
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Documenten</title>
  <link rel="icon" href="./fotos/favicon/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="./css/style.css"><link rel="stylesheet" href="./css/navbar.css">
</head>
<body style="height:auto;min-height:100vh;align-items:flex-start;padding-top:9rem;">
  <?php include "header.php"; ?>
  <main style="width:100%;max-width:620px;margin:0 auto;padding:0 1rem;">
    <div class="container1" style="width:100%;margin-top:0;">
      <h1 class="welcome-name" style="font-size:1.8rem;">Douanedocument uploaden</h1>
      <?php if ($msg) { echo '<p>'.$msg.'</p>'; } ?>
      <form action="upload.php" method="POST" enctype="multipart/form-data">
        <div class="input-group2"><input type="file" name="doc" required></div>
        <div class="input-group2"><button name="submit" class="btn2">Uploaden</button></div>
      </form>
      <p style="margin-top:1.5rem;"><a href="dashboard.php">&larr; Terug naar dashboard</a></p>
    </div>
  </main>
</body>
</html>
