<?php
/* ============================================================
 * OPZETTELIJK KWETSBARE TRAININGSMACHINE - ALLEEN IN HET LAB.
 * Niet op het internet plaatsen. Zie BOUW-README.md.
 * ============================================================ */

// Aparte databasegebruiker voor de site (geen root).
// Maak deze aan op de VM:
//   CREATE USER 'cybertron'@'localhost' IDENTIFIED BY 'havenpoort';
//   GRANT SELECT, INSERT ON cybertron_port.* TO 'cybertron'@'localhost';
$servername = "localhost";
$username   = "cybertron";
$password   = "havenpoort";
$dbname     = "cybertron_port";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Verbinding mislukt: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?>
