<?php if (session_status() === PHP_SESSION_NONE) { session_start(); } ?>
<header>
  <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand text-white" href="<?php echo isset($_SESSION['username']) ? 'dashboard.php' : 'index.php'; ?>">
        <img style="height:3rem;" src="./fotos/logo-inverted.png" alt="">
        <em class="navbar-logo-text">Cybertron Port Authority</em>
      </a>
      <div class="navbar-collapse">
        <ul class="navbar-nav ms-auto py-4 py-lg-0">
          <?php if (isset($_SESSION['username'])) {
            echo '<li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>';
            echo '<li class="nav-item"><a class="nav-link" href="manifest.php?id=1041">Manifesten</a></li>';
            if ($_SESSION['role'] === 'beheer') {
              echo '<li class="nav-item"><a class="nav-link" href="beheer.php">Beheer</a></li>';
            }
            echo '<li class="nav-item"><div class="main-button"><a href="./logout.php">Uitloggen</a></div></li>';
          } else {
            echo '<li class="nav-item"><a class="nav-link" href="aanmelden.php">Lading aanmelden</a></li>';
            echo '<li class="nav-item"><div class="main-button"><a href="./login.php">Inloggen</a></div></li>';
          } ?>
        </ul>
      </div>
    </div>
  </nav>
</header>
<script src="./js/navbar-scroll.js" defer></script>
